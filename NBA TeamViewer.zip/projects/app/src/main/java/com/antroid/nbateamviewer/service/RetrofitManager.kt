package com.antroid.nbateamviewer.service

class RetrofitManager {
}