package com.antroid.nbateamviewer.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

import com.antroid.nbateamviewer.R;
import com.antroid.nbateamviewer.ui.team.TeamListFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.main_activity_container,
                        new TeamListFragment())
                .commit();
    }
}