package com.antroid.nbateamviewer.ui.team

import androidx.lifecycle.ViewModel

class TeamListViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}