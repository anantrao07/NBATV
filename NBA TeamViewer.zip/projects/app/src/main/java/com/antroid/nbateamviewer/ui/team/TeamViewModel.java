package com.antroid.nbateamviewer.ui.team;

import androidx.lifecycle.ViewModel;

public class TeamViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}