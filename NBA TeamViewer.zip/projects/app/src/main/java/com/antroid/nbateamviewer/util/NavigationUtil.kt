package com.antroid.nbateamviewer.util

object NavigationUtil  {

    fun pushOrPopFragment(fragment: Fragment, )
}